import tweepy

auth = tweepy.OAuthHandler("9NzEUmBdutUZwFh1rshaFdycV", "nqtPo1NSEU3jVBwLzYuUPEPN5a4GFh9RTl6HR22gluZHlmghKK")
auth.set_access_token("939434498114052096-b5sD66cNvTebtKc10BmWXA7X33v8K70", "yBQ0K1raNnfzGQ1ywc2Rn5OosvlVDuHiOnYuSZINiU8Br")

api = tweepy.API(auth)

for status in tweepy.Cursor(api.search, q="tubirfess", count=200, tweet_mode='extended', include_entities=True).items():
    # process status here
    print(status.full_text)
